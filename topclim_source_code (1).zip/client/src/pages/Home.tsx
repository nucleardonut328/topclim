import { useEffect } from "react";

export default function Home() {
  useEffect(() => {
    // Загружаем HTML контент из public/template.html (не index.html!)
    fetch("/template.html")
      .then((res) => res.text())
      .then((html) => {
        // Извлекаем содержимое из .site-wrap (основной контейнер шаблона)
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, "text/html");
        const siteWrap = doc.querySelector(".site-wrap");
        
        // Вставляем только контент, БЕЗ повторного <div id="root">
        const container = document.getElementById("html-content");
        if (container && siteWrap) {
          container.innerHTML = siteWrap.innerHTML;
          
          // Инициализируем jQuery плагины ТОЛЬКО один раз
          initializePlugins();
        }
      })
      .catch((err) => console.error("Ошибка загрузки template.html:", err));
  }, []);

  const initializePlugins = () => {
    // jQuery плагины инициализируются в main.tsx через setTimeout
    // Здесь просто убеждаемся, что DOM готов
    if (typeof window !== "undefined") {
      // Триггер события для инициализации плагинов
      window.dispatchEvent(new Event("templateLoaded"));
    }
  };

  return (
    <div id="html-content">
      {/* Контент будет загружен здесь */}
    </div>
  );
}
