import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "./contexts/ThemeContext";
import { useEffect, useState } from "react";

function ErrorBoundary({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

function App() {
  const [htmlContent, setHtmlContent] = useState<string>("");
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Загружаем HTML контент из public/template.html
    fetch("/template.html")
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        return res.text();
      })
      .then((html) => {
        // Парсим HTML
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, "text/html");
        
        // Извлекаем body content
        const bodyContent = doc.body.innerHTML;
        setHtmlContent(bodyContent);
        
        // Копируем атрибуты body
        const bodyAttrs = doc.body.attributes;
        for (let i = 0; i < bodyAttrs.length; i++) {
          document.body.setAttribute(bodyAttrs[i].name, bodyAttrs[i].value);
        }
        
        setIsLoaded(true);
      })
      .catch((error) => {
        console.error("Ошибка загрузки контента:", error);
        setHtmlContent(`<div style="padding: 20px; color: red;">Ошибка загрузки: ${error.message}</div>`);
        setIsLoaded(true);
      });
  }, []);

  // Загружаем скрипты после рендера контента
  useEffect(() => {
    if (!isLoaded) return;

    // Загружаем скрипты асинхронно и параллельно
    const scripts = [
      "/js/jquery-3.3.1.min.js",
      "/js/jquery-ui.js",
      "/js/popper.min.js",
      "/js/bootstrap.min.js",
      "/js/owl.carousel.min.js",
      "/js/jquery.countdown.min.js",
      "/js/jquery.easing.1.3.js",
      "/js/aos.js",
      "/js/jquery.fancybox.min.js",
      "/js/jquery.sticky.js",
      "/js/main.js",
    ];

    // Загружаем все скрипты параллельно с defer
    scripts.forEach((src) => {
      const script = document.createElement("script");
      script.src = src;
      script.defer = true;
      script.async = true;
      document.body.appendChild(script);
    });
  }, [isLoaded]);

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <div id="root-content" dangerouslySetInnerHTML={{ __html: htmlContent }} />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
