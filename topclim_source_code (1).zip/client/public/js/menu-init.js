// Инициализация мобильного меню
(function() {
  'use strict';

  // Ждем загрузки jQuery
  if (typeof jQuery === 'undefined') {
    setTimeout(arguments.callee, 100);
    return;
  }

  var $ = jQuery;

  $(document).ready(function() {
    console.log('Инициализация мобильного меню');

    // Клонируем меню в мобильную версию
    var siteMenuClone = function() {
      $('.js-clone-nav').each(function() {
        var $this = $(this);
        var cloned = $this.clone().attr('class', 'site-nav-wrap');
        $('.site-mobile-menu-body').append(cloned);
        console.log('Меню клонировано');
      });
    };

    siteMenuClone();

    // Обработчик клика на кнопку меню
    $('body').on('click', '.js-menu-toggle', function(e) {
      e.preventDefault();
      console.log('Клик по меню-тоггл');

      if ($('body').hasClass('offcanvas-menu')) {
        $('body').removeClass('offcanvas-menu');
        $(this).removeClass('active');
        console.log('Меню закрыто');
      } else {
        $('body').addClass('offcanvas-menu');
        $(this).addClass('active');
        console.log('Меню открыто');
      }
    });

    // Закрытие меню при клике вне его
    $(document).mouseup(function(e) {
      var container = $(".site-mobile-menu");
      if (!container.is(e.target) && container.has(e.target).length === 0) {
        if ($('body').hasClass('offcanvas-menu')) {
          $('body').removeClass('offcanvas-menu');
          $('.js-menu-toggle').removeClass('active');
          console.log('Меню закрыто (клик вне)');
        }
      }
    });

    // Закрытие меню при клике на ссылку
    $('.site-mobile-menu a').on('click', function() {
      $('body').removeClass('offcanvas-menu');
      $('.js-menu-toggle').removeClass('active');
      console.log('Меню закрыто (клик на ссылку)');
    });
  });
})();
