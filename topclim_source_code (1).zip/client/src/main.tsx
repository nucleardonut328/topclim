import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Просто рендерим React приложение
createRoot(document.getElementById("root")!).render(<App />);

// Загружаем скрипты ПОСЛЕДОВАТЕЛЬНО после рендера
// Используем флаг, чтобы не загружать дважды
let scriptsLoaded = false;

function loadScriptsSequentially() {
  if (scriptsLoaded) return;
  scriptsLoaded = true;

  const scripts = [
    "/js/jquery-3.3.1.min.js",
    "/js/jquery-ui.js",
    "/js/popper.min.js",
    "/js/bootstrap.min.js",
    "/js/owl.carousel.min.js",
    "/js/jquery.countdown.min.js",
    "/js/jquery.easing.1.3.js",
    "/js/aos.js",
    "/js/jquery.fancybox.min.js",
    "/js/jquery.sticky.js",
    "/js/main.js",
  ];

  let loadedCount = 0;

  function loadNext() {
    if (loadedCount >= scripts.length) {
      console.log("✓ Все скрипты загружены");
      return;
    }

    const src = scripts[loadedCount];
    const script = document.createElement("script");
    script.src = src;
    script.defer = true;
    
    script.onload = () => {
      console.log(`✓ Загружен: ${src}`);
      loadedCount++;
      loadNext();
    };

    script.onerror = () => {
      console.warn(`✗ Ошибка загрузки: ${src}`);
      loadedCount++;
      loadNext();
    };

    document.body.appendChild(script);
  }

  loadNext();
}

// Начинаем загрузку скриптов с задержкой
setTimeout(loadScriptsSequentially, 100);

// Слушаем событие загрузки шаблона
window.addEventListener("templateLoaded", () => {
  console.log("Шаблон загружен, переинициализируем плагины");
  // Если нужна переинициализация - добавить здесь
});
